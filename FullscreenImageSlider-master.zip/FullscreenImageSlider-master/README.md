# Fullscreen responsive image slider

An image slider that is fullscreen and responsive.

Icons are taken from fontawesome.

Images change on either click or after five seconds.

## Screenshot

on iPhoneX

<img src="slider_iphoneX.gif" width=500>



## Author
* Albert Stjärne (https://github.com/AlbertStjarne)